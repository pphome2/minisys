<?php

 #
 # nvr - language file
 #
 # info: main folder copyright file
 #
 #


# system zone / rendszerhez szükséges
$L_APPNAME="NVR";

$L_BACKPAGE="Vissza";
$L_ERROR_VIDEO="A böngésző nem támogatja a videó lejátszását.";
$L_TABLE=array('Név','Fájl','Videó');
$L_DOWNLOAD_TEXT='Letöltés';
$L_HEAD_TEXT='Tárolt videók';
$L_PLAYER="Lejátszás";
$L_DOWNLOAD="Letöltés";
$L_NOFILE="Fájl nem elérhető.";
$L_FILES="Tárolt fájlok";
$L_DAYS=array('Ma','-1 nap','-2 nap','-3 nap');

?>
