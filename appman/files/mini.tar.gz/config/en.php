<?php

 #
 # MiniApps - framework
 #
 # info: main folder copyright file
 #
 #

# system zone
$L_SITENAME="Demo";
$L_SITEHOME="Home";
$L_MTHOME="Demo";
$L_ADMINISTRATION="Administration";
$L_THEME="Next theme";
$L_PRIVACY_MENU="Privacy";
$L_PASS="Access code";
$L_BUTTON_NEXT="Next";
$L_LOGOUT="Logout";
$L_PRINT="Print";
$L_BACKPAGE="Go back";
$L_SEARCH="Search";

# system but need change

$L_COOKIE_TEXT="The site use cokies. Please read the Privacy page.";

$L_PRIVACY_HEADER="Privacy page address";
$L_PRIVACY_TEXT=" Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec in justo sodales, mattis purus quis, ultricies sem.
					Donec porttitor volutpat blandit. Ut metus velit, feugiat id finibus vitae, vestibulum non metus. Nulla quis
					orci urna. In ligula ex, fringilla at eleifend ac, aliquam a lectus. Duis cursus lorem a ex aliquam dapibus.
					Nulla facilisi. Nunc nulla massa, hendrerit sed magna id, convallis volutpat elit. Donec auctor placerat risus
					eu placerat. Nullam nec iaculis urna. Mauris ut ornare augue. Ut volutpat hendrerit nunc.
					<br><br>
					Cras sit amet ex sapien. Integer enim erat, tempor a sem eleifend, blandit aliquet urna. Suspendisse convallis
					mauris vel congue tempus. Vestibulum varius, lectus nec venenatis porta, magna ligula elementum massa, sit amet
					mollis odio leo at leo. Nunc semper tellus in massa dictum, ut volutpat massa dictum. Vivamus pharetra ipsum vitae
					augue consectetur, in scelerisque lacus scelerisque. Donec semper leo a enim lacinia molestie. Nullam fermentum
					dolor ac tellus vulputate, id vulputate tortor ullamcorper. Duis vitae sapien nec enim dapibus accumsan. Etiam nec
					vestibulum nibh, eu sodales risus. Aenean erat ante, suscipit at malesuada nec, iaculis nec felis. ";


# local app zone

$L_MENU1="List";

$L_MENU2="AdminList";



?>
