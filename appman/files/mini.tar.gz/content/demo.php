<?php

 #
 # MiniApp - demo
 #
 # info: main folder copyright file
 #
 #





function searchpage(){
	echo("search page");
}

	
function privacypage(){
	echo("privacy page");
}

function printpage(){
	echo("print page");
}



function main(){
	echo("main page");
	echo("<br /><br />");
	echo("<a href=print.php target=_blank>print page demo</a>");
}




?>
