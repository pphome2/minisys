<?php

 #
 # MiniApp - demo
 #
 # info: main folder copyright file
 #
 #

echo("Menu demo. File: list.php");

?>
