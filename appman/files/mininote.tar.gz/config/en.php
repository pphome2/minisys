<?php

 #
 # MiniApps - framework
 #
 # info: main folder copyright file
 #
 #

# system zone
$L_SITENAME="Note";
$L_SITEHOME="Home";
$L_MTHOME="Note";
$L_ADMINISTRATION="Administration";
$L_THEME="Next theme";
$L_PRIVACY_MENU="Privacy";
$L_USERNAME="Username";
$L_PASSWORD="Password";
$L_PASS="Access code";
$L_BUTTON_NEXT="Next";
$L_LOGOUT="Logout";
$L_PRINT="Print";
$L_BACKPAGE="Go back";
$L_SEARCH="Search";

# system but need change

$L_COOKIE_TEXT="The site use cokies. Please read the Privacy page.";

$L_PRIVACY_HEADER="Privacy page address";
$L_PRIVACY_TEXT=" Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec in justo sodales, mattis purus quis, ultricies sem.
					Donec porttitor volutpat blandit. Ut metus velit, feugiat id finibus vitae, vestibulum non metus. Nulla quis
					orci urna. In ligula ex, fringilla at eleifend ac, aliquam a lectus. Duis cursus lorem a ex aliquam dapibus.
					Nulla facilisi. Nunc nulla massa, hendrerit sed magna id, convallis volutpat elit. Donec auctor placerat risus
					eu placerat. Nullam nec iaculis urna. Mauris ut ornare augue. Ut volutpat hendrerit nunc.
					<br><br>
					Cras sit amet ex sapien. Integer enim erat, tempor a sem eleifend, blandit aliquet urna. Suspendisse convallis
					mauris vel congue tempus. Vestibulum varius, lectus nec venenatis porta, magna ligula elementum massa, sit amet
					mollis odio leo at leo. Nunc semper tellus in massa dictum, ut volutpat massa dictum. Vivamus pharetra ipsum vitae
					augue consectetur, in scelerisque lacus scelerisque. Donec semper leo a enim lacinia molestie. Nullam fermentum
					dolor ac tellus vulputate, id vulputate tortor ullamcorper. Duis vitae sapien nec enim dapibus accumsan. Etiam nec
					vestibulum nibh, eu sodales risus. Aenean erat ante, suscipit at malesuada nec, iaculis nec felis. ";


# local app zone

$L_BUTTON_ALL="Next";

$L_BUTTON_SAVE="Save";
$L_BUTTON_DELETE="Delete";
$L_BUTTON_PRINT="Print";

$L_NORIGHTS="No rights to do.";
$L_FILE_NOT_FOUND="File not found.";

$L_NEWDIR="New folder";

$L_NEWDIR_MESS="Folder created.";
$L_NEWDIR_EXISTS="Folder exists";
$L_NEWDIR_ERROR="Folder creation error.";

$L_DELDIR_MESS="Folder deleted.";
$L_DELDIR_ERROR="Folder deletion error.";

$L_DELNOTE_MESS="Note deleted.";
$L_DELNOTE_ERROR="Note deletion error..";
$L_DELNOTE_NOTFOUND="Note not exsists.";

$L_MAPPANAME="Folders";
$L_MAPPA_ACTUAL="items";

$L_BUTTON_PREV="Back";

$L_NEW_NOTE="New note";

$L_BUTTON_DELDIR="Delete";
$L_DELDIR="Folder delete";

$L_SELECT_ITEM="- Select item -";

$L_PRINT_NAME="Folder";
$L_PRINT_ITEM="item";


?>
