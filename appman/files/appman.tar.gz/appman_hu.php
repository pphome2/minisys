<?php

 #
 # AppMan - language file
 #
 # info: main folder copyright file
 #
 #


# system zone / rendszerhez szükséges
$L_APPNAME="AppMan - telepítő, frissítő program";

$L_ERROR_COPY="Hiba a másolás közben. Fájl nem elérhető.";
$L_ERROR_INDEX="Indító fájl nem található. (index.html, index.php) A leírásában ellenőrizze a program indításának módját.";

$L_START_APP="Kattintson a program indításához.";
$L_START_BUTTON="A program indítása";

$L_INSTALL_OK="A telepítés megtörtént.";

$L_UPDATE_OK="A frissítés megtörtént";
$L_UPDATE_NO="Nincs új frissítés.";
$L_UPDATE_OLD="Régi verzió";
$L_UPDATE_NEW="Új verzió";

$L_BUTTON_CONFIG="Beállítások ellenőrzése";

$L_BUTTON_END="Kilépés";

?>
