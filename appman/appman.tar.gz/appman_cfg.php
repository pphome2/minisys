<?php

 #
 # AppMan - config
 #
 # info: main folder copyright file
 #
 #


# configuration

# copyright link
$AM_COPYRIGHT="© ".date("Y").". <a href=https://github.com/pphome2>Github</a>";

# title, home link
$AM_NAME="AppMan";

# directories
$AM_DATA_DIR="data";
$AM_CSS="appman_w.css";

# language
$AM_LANGFILE="appman_hu.php";

?>
