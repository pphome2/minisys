<?php

 #
 # AppMan - language file
 #
 # info: main folder copyright file
 #
 #


# system zone / rendszerhez szükséges
$L_APPNAME="AppMAn - telepítő, frissítő program";

?>
