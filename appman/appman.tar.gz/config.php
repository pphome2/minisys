<?php

 #
 # MiniSys - config app
 #
 # info: main folder copyright file
 #
 #

header("Location: ./config_sys/sys_main.php");

?>
